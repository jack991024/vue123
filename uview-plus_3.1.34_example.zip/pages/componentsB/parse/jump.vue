<template>
  <view>
    跳转测试页面
  </view>
</template>

<script>
export default {}
</script>

<style>
</style>
