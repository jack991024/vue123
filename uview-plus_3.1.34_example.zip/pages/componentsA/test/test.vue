<template>
	<view>
		<u-list style="height: 500px; background-color: red;">
			<u-list-item>
				<u-image src="https://img2020.cnblogs.com/blog/35695/202112/35695-20211222112522991-1769312387.jpg"></u-image>
			</u-list-item>
			<u-list-item>
				<u-image src="https://img2020.cnblogs.com/blog/35695/202112/35695-20211222112522991-1769312387.jpg"></u-image>
			</u-list-item>
			<u-list-item>
				<u-image src="https://img2020.cnblogs.com/blog/35695/202112/35695-20211222112522991-1769312387.jpg"></u-image>
			</u-list-item>
			<u-list-item>
				<u-image src="https://img2020.cnblogs.com/blog/35695/202112/35695-20211222112522991-1769312387.jpg"></u-image>
			</u-list-item>
			<u-list-item>
				<u-image src="https://img2020.cnblogs.com/blog/35695/202112/35695-20211222112522991-1769312387.jpg"></u-image>
			</u-list-item>
			<u-list-item>
				<u-image src="https://img2020.cnblogs.com/blog/35695/202112/35695-20211222112522991-1769312387.jpg"></u-image>
			</u-list-item>
			<u-list-item>
				<u-image src="https://img2020.cnblogs.com/blog/35695/202112/35695-20211222112522991-1769312387.jpg"></u-image>
			</u-list-item>
		</u-list>
	</view>
</template>

<script>
	export default {
		
	}
</script>