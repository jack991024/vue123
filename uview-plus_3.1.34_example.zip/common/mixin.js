export default {
    data() {
        return {
			isWeixin: true
        }
    }
}
