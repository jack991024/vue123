export default {
    baseUrl: 'https://api.youzixy.com'
}
