import defprops from '../../libs/config/props';
export default {
    props: {
        bgColor: {
            type: String,
            default: defprops.statusBar.bgColor
        }
    }
}
