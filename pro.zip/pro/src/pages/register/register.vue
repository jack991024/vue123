<template>
  <view id="body">

    <view id="login">
      <view id="mobile">
        <up-input
            placeholder="请输入手机号"
            prefixIcon="phone"
            border="bottom"
            v-model="login.userInfo.phoneMobile"
            prefixIconStyle="font-size: 22px;color: #909399"
        ></up-input>
      </view>
      <view id="verifyCode">
        <up-input
            placeholder="验证码"
            prefixIcon="lock"
            border="bottom"
            v-model="login.userInfo.verifyCode"
            prefixIconStyle="font-size: 22px;color: #909399"
        >
          <template #suffix>
            <view class="u-demo-block__content">
              <u-code
                  @change="codeChange2"
                  keep-running
                  start-text="点我获取验证码"
              ></u-code>
              <text
                  @tap="getCode2"
                  :text="tips2"
                  class="u-page__code-text"
              >{{ tips2 }}
              </text>
            </view>
          </template>
        </up-input>
      </view>
      <view id="password">
        <up-input
            placeholder="请输入密码"
            prefixIcon="lock"
            border="bottom"
            v-model="login.userInfo.password"
            prefixIconStyle="font-size: 22px;color: #909399"
            type="password"
        >
        </up-input>
      </view>
      <view id="submit">
        <up-button type="primary" text="注册"></up-button>
      </view>

      <u-radio-group>
        <u-radio shape="square" label="点击“按钮勾选”即同意《智考典隐私政策》" style="width:80%;display:inline-block;white-space: pre-wrap; word-wrap: break-word;height: auto;">
        </u-radio>
      </u-radio-group>
    </view>
  </view>
</template>

<script setup>
import {ref} from "vue";

let seconds = ref()

let tips2 = ref('获取验证码')

const login = ref({
  userInfo: {
    phoneMobile: "",
    verifyCode: "",
    password: ""
  }
})

function codeChange2(text) {
  this.tips2 = text;
}

function getCode2() {
  if (this.$refs.uCode2.canGetCode) {
    // 模拟向后端请求验证码
    uni.showLoading({
      title: '正在获取验证码'
    })
    setTimeout(() => {
      uni.hideLoading();
      // 这里此提示会被this.start()方法中的提示覆盖
      uni.$u.toast('验证码已发送');
      // 通知验证码组件内部开始倒计时
      this.$refs.uCode2.start();
    }, 2000);
  } else {
    uni.$u.toast('倒计时结束后再发送');
  }
}

</script>

<style lang="scss">
#register {
  padding: 12px 14px 9px 280px;
  display: block;
  overflow-wrap: break-word;
  color: rgba(38, 38, 38, 1);
  font-size: 20px;
  font-family: "PingFang SC", serif;
  font-weight: 500;
  text-align: right;
  white-space: nowrap;
  line-height: 25px;
}

#body {
  padding: 75px 16px 90px 16px;

  #logo {
    width: 84px;
    height: 84px;
    display: block;
    margin: 0 auto;
  }

  #login {
    margin-top: 101px;
    margin-bottom: 210px;

    #mobile {
      display: block;
      margin-bottom: 15px;
    }

    #verifyCode {
      display: block;
      margin-bottom: 15px;
    }

    #password {
      display: block;
      margin-bottom: 30px;
    }

    #footer {
      #verifyCodeLogin {
        border: 1px rebeccapurple solid;
        margin: 0 auto;
      }
    }
  }


  input::placeholder {
    font-size: 3px;
  }
}

.u-page {
  &__code-text {
    color: $u-primary;
    font-size: 15px;
  }
}

.u-demo-block__content {
  @include flex;
}

</style>
