<template>
  <view>
    <view id="register">
      <u-link text="立即注册" @click="registerRouter" mpTips=""></u-link>
    </view>
  </view>
  <view id="body">
    <view>
      <image id="logo" src="./static/login/logo.png"/>
    </view>

    <view id="login">
      <view id="mobile">
        <up-input
            placeholder="请输入手机号"
            prefixIcon="phone"
            border="bottom"
            v-model="login.userInfo.phoneMobile"
            prefixIconStyle="font-size: 22px;color: #909399"
        ></up-input>
      </view>
      <view id="password">
        <up-input
            placeholder="请输入密码"
            prefixIcon="lock"
            border="bottom"
            v-model="login.userInfo.password"
            prefixIconStyle="font-size: 22px;color: #909399"
            type="password"
        >
          <template #suffix>
            <u-link href="https://uviewui.com/" text="忘记密码？" @click=""></u-link>
          </template>
        </up-input>
      </view>
      <view id="submit">
        <up-button type="primary" text="登陆"></up-button>
      </view>

      <view id="footer">
        <u-divider text="其他登陆方式" :hairline="true"></u-divider>
        <view id="verifyCodeLogin">
          <view class="">
            <u-icon
                name="phone"
                size="30"
                color="#909399"
                @click=""
            ></u-icon>
          </view>
          <text id="verifyCodeText">验证码</text>
        </view>
      </view>
    </view>
  </view>
</template>

<script setup>
import {ref} from "vue";

const login = ref({
  userInfo: {
    phoneMobile: "",
    password: ""
  }
})

function registerRouter() {
  uni.redirectTo({
    url: '/pages/register/register'
  });
}
</script>

<style lang="scss">
#register {
  padding: 12px 14px 9px 280px;
  display: block;
  overflow-wrap: break-word;
  color: rgba(38, 38, 38, 1);
  font-size: 20px;
  font-family: "PingFang SC", serif;
  font-weight: 500;
  text-align: right;
  white-space: nowrap;
  line-height: 25px;
}

#body {
  padding: 75px 16px 90px 16px;

  #logo {
    width: 84px;
    height: 84px;
    display: block;
    margin: 0 auto;
  }

  #login {
    margin-top: 101px;
    margin-bottom: 210px;

    #mobile {
      display: block;
      margin-bottom: 15px;
    }

    #password {
      display: block;
      margin-bottom: 30px;
    }

    #submit {
      display: block;
      margin-bottom: 80px;
    }

    #footer {
      #verifyCodeLogin {
        display: block;
        text-align: center;
      }
      #verifyCodeText{
        font-size:14px;color:#909399;
      }
    }
  }


  input::placeholder {
    font-size: 3px;
  }
}


</style>
